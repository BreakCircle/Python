import pymysql
pymysql.install_as_MySQLdb()

'''
如果你要实用MySQL数据库的话，此处需要配置。
https://github.com/PyMySQL/PyMySQL/
'''
