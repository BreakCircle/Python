# coding = utf-8
from django.test import TestCase
from django.test import Client
from django.http import HttpRequest
from django.contrib.auth.models import User
from sign.models import Event, Guest
from datetime import datetime


class test_index(TestCase):
    """测试index登录首页"""

    def test_index_page_render_templite(self):
        self.c = Client()
        response = self.c.get('/index/')
        self.assertEqual(response.status_code, 200)
        self.assertTemplateUsed(response, 'index.html')


class loginAction(TestCase):
    """测试登录动作"""

    def setUp(self):
        User.objects.create_user('xiaoming', '123@163.com', 'admin')
        self.c = Client()

    def test_login_index(self):
        '''增加用户'''
        user = User.objects.get(username='xiaoming')
        self.assertEqual(user.username, 'xiaoming')
        self.assertEqual(user.email, '123@163.com')

    def test_login_username_password_null(self):
        '''用户名和密码为空'''
        response = self.c.post(
            '/login_action/', {'username': '', 'password': ''})
        self.assertEqual(response.status_code, 200)
        self.assertIn(b'username or password null', response.content)

    def test_login_username_password_wrong(self):
        '''用户名和密码错误'''
        response = self.c.post(
            '/login_action/', {'username': 'zs', 'password': 'admin'})
        self.assertEqual(response.status_code, 200)
        self.assertIn(b'username or password error', response.content)

    def test_login_action_success(self):
        '''登录成功'''
        data = {'username': 'xiaoming', 'password': 'admin'}
        response = self.c.post('/login_action/', data)
        self.assertEqual(response.status_code, 302)


class EventManageTest(TestCase):
    '''发布会管理'''

    def setUp(self):

        Event.objects.create(name='meizu', limit=2000, address='beijing',
                             status=1, start_time='2017-12-30 14:30:00')
        self.c = Client()

    def test_add_event(self):
        '''验证虚拟加载数据'''
        event = Event.objects.get(name='meizu')
        self.assertEqual(event.name, 'meizu')
        self.assertEqual(event.address, 'beijing')
        self.assertEqual(event.status, 1)
        self.assertEqual(event.limit, 2000)
        self.assertEqual(event.start_time, datetime(2017, 12, 30, 14, 30))

    def test_event_manage_success(self):
        '''测试发布会：魅蓝'''
        response = self.c.post('/event_manage/')
        self.assertEqual(response.status_code, 200)  # 200
        self.assertIn(b'meizu', response.content)
        self.assertIn(b'beijing', response.content)

    def test_event_manage_search_success(self):
        '''测试查询'''
        response = self.c.post('/sreach_name/', {'name': 'meizu'})
        self.assertEqual(response.status_code, 200)
        self.assertIn(b'meizu', response.content)


class GuestManageTest(TestCase):
    """嘉宾管理"""

    def setUp(self):
        Event.objects.create(id=1, name='meizu', limit=2000, address='beijing',
                             status=1, start_time='2017-12-30 14:30:00')
        Guest.objects.create(realname='zz', phone=18792913729,
                             email='123@163.com', sign=0, event_id=1)
        self.c = Client()

    def test_add_guest_success(self):
        '''测试嘉宾信息'''
        guest = Guest.objects.get(realname='zz')
        self.assertEqual(guest.realname, 'zz')
        self.assertEqual(guest.phone, '18792913729')
        self.assertEqual(guest.email, '123@163.com')
        self.assertFalse(guest.sign)

    def test_guest_manage_success(self):
        '''测试嘉宾信息'''
        response = self.c.post('/guest_manage/')
        self.assertEqual(response.status_code, 200)
        self.assertIn(b'zz', response.content)
        self.assertIn(b'18792913729', response.content)

    def test_guest_manage_search_success(self):
        response = self.c.post('/sreach_phone/', {'phone': '18792913729'})
        self.assertEqual(response.status_code, 200)
        self.assertIn(b'zz', response.content)


# class SearchEvent(TestCase):

#     def setUp(self):

#         self.url = 'http://127.0.0.1:8000/sreach_name/'
#         self.c = Client()

#     def test_event(self):
#         response = self.c.post(self.url, {'name': 'meilan'})
#         self.assertEqual(response.status_code, 200)
#         self.assertIn(b'meilan', response.content)
#         self.assertIn(b'shenzhen', response.content)


# class Log(TestCase):

#     def setUp(self):
#         User.objects.create('zs', 'zs@136.com', 'admin')

#     def c(self):
#         pass
#         response = User.objects.get(username='zs')
#         self.assertEqual(response.status_code, 200)
