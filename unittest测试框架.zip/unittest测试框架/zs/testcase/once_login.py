# coding=utf-8
import unittest
import sys
sys.path.append("\\zs\\public")
import login


class Guest_Test(unittest.TestCase):

    '''登录一次进行'''

    def test_once_login(self):

        user = "chengjun"
        pwd = "cj123456"
        url = "http://127.0.0.1:8000"
        login.login(user, pwd, url)
        
