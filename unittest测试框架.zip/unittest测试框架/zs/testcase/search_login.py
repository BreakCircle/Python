#coding = utf-8
from selenium import webdriver
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait
import sys
import os
import time
import re
import unittest
import csv
import threading
from unittest import TestCase


class Search_event(unittest.TestCase):
    """登录guest"""

    def setUp(self):

        self.driver = webdriver.Firefox()

    def test_login(self):
        '''登录查询验证元素'''
        self.user = "lk"
        self.pwd = "lk123456"
        self.url = "http://127.0.0.1:8000"
        self.driver.get(self.url)
        self.driver.implicitly_wait(5)
        self.driver.find_element_by_id("inputUsername").clear()
        self.driver.find_element_by_name("username").send_keys(self.user)
        time.sleep(5)
        self.driver.find_element_by_xpath("//input[@name='password']")
        self.driver.find_element_by_css_selector(
            "input#inputPassword").send_keys(self.pwd)
        self.driver.find_element_by_xpath("//button[@type='submit']").submit()

        # 查询发布会
        self.driver.find_element_by_css_selector(
            "html body div.container.theme-showcase div.page-header div#navbar.navbar-collapse.collapse form.navbar-form div.form-group input.form-control").clear()
        self.driver.find_element_by_css_selector(
            "html body div.container.theme-showcase div.page-header div#navbar.navbar-collapse.collapse form.navbar-form div.form-group input.form-control").send_keys("小米")
        self.driver.find_element_by_xpath(
            "/html/body/div/div[1]/div/form/button").click()

        # 检查元素
        event_id = self.driver.find_element_by_xpath(
            "/html/body/div/div[2]/div/table/tbody/tr/td[1]").text
        event_name = self.driver.find_element_by_xpath(
            "/html/body/div/div[2]/div/table/tbody/tr/td[2]").text
        event_stasus = self.driver.find_element_by_xpath(
            "/html/body/div/div[2]/div/table/tbody/tr/td[3]").text
        event_address = self.driver.find_element_by_xpath(
            "/html/body/div/div[2]/div/table/tbody/tr/td[4]").text
        print(event_id, event_name, event_stasus, event_address)

        # 添加断言
        self.assertEqual(event_id, "1")
        self.assertTrue(event_stasus)
        self.assertEqual(event_name, "小米7发布会")
        self.assertIn("北京", event_address)
        self.driver.quit()

if __name__ == '__main__':
    unittest.main()
