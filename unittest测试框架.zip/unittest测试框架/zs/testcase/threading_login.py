#coding = utf-8
from selenium import webdriver
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait
import sys
import os
import time
import re
import unittest
import csv
import threading

sys.path.append("\\zs\\public")
import login


class Threading_login(unittest.TestCase):
    '''多线程同时登录'''

    def test_login_threads(self):
        '''多线程登录'''

        # 新建线程数列
        threads = []

        # 读取csv文件
        url = "http://127.0.0.1:8000"
        name = "D:\\zs\\data\\name.csv"
        f = open(name, "r")
        data = csv.reader(f)
        # 加入多线程
        for i in data:
            t = threading.Thread(target=login.login, args=(i[0], i[1], url))
            threads.append(t)
        # 多线程执行
        for s in range(len(threads)):
            threads[s].start()
        for s in range(len(threads)):
            threads[s].join()
        f.close()


if __name__ == '__main__':
    unittest.main()
