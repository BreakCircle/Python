# coding=utf-8
import unittest
import sys
sys.path.append("\\zs\\public")
import pylogin


class Guest_Test(unittest.TestCase):
    '''登录，查询，验证，三次进行'''

    def test_three_cases(self):
        user = "chengtao"
        pwd = "ct123456"
        url = "http://127.0.0.1:8000"
        m = pylogin.Login_guest(user, pwd, url)
        m.test_login()
        m.test_search_name()
        m.test_assert_element()
if __name__ == '__main__':
    unittest.main()
