#coding = utf-8
from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait
import sys

import time

# 定义登录的方法


def login(user, pwd, url):
    driver = webdriver.Firefox()
    driver.get(url)
    driver.implicitly_wait(5)
    driver.find_element_by_id("inputUsername").clear()
    driver.find_element_by_name("username").send_keys(user)
    time.sleep(5)
    driver.find_element_by_xpath("//input[@name='password']")
    driver.find_element_by_css_selector(
        "input#inputPassword").send_keys(pwd)
    driver.find_element_by_xpath("//button[@type='submit']").submit()
    driver.quit()
