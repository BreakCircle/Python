# -*-coding:utf8-*-
import os

def find_newest_report(report_dir):
    report = report_dir
    lists = os.listdir(report)
    print (u"测试报告:%s" %lists)
    lists.sort(key=lambda x: os.path.getmtime(report + "\\" + x)
               if not os.path.isdir(report + "\\" + x) else 0)
    file_new = os.path.join(report, lists[-1])
    return file_new