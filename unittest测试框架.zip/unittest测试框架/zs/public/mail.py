# coding=utf-8

import time
import os
import smtplib
import HTMLTestRunner
import unittest
from email.mime.text import MIMEText




def sendmail(file_new):
    mail_from = "*********@163.com"
    mail_to = "**********@qq.com"
    username = "*********"
    passport = "********"
    f = open(file_new, "rb")
    text = f.read()
    f.close()
    msg = MIMEText(text, "html", "utf-8")
    msg["Subject"] = u"测试报告"
    smtp = smtplib.SMTP()
    smtp.connect("smtp.163.com")
    smtp.login(username, passport)
    smtp.sendmail(mail_from, mail_to, msg.as_string())
    smtp.quit()
    print (u"邮件发送成功：%s" %file_new)



