#coding = utf-8
from selenium import webdriver
from selenium.webdriver.common.keys import Keys
import time
import unittest


class Login_guest(unittest.TestCase):
    """登录guest"""

    def __init__(self, user, pwd, url):

        self.user = user
        self.pwd = pwd
        self.url = url

    def test_login(self):
        self.driver = webdriver.Firefox()
        self.driver.get(self.url)
        self.driver.implicitly_wait(5)
        self.driver.find_element_by_id("inputUsername").clear()
        self.driver.find_element_by_name("username").send_keys(self.user)
        time.sleep(5)
        self.driver.find_element_by_xpath("//input[@name='password']")
        self.driver.find_element_by_css_selector(
            "input#inputPassword").send_keys(self.pwd)
        self.driver.find_element_by_xpath("//button[@type='submit']").submit()
    
if __name__ == '__main__':
    unittest.main()
