# -*-coding:utf8-*-
import time
import HTMLTestRunner
import unittest


def runcases(case_dir, report_dir, report_name, title_name, description_name):
    '''执行用例'''
    utest = unittest.TestSuite()
    # 测试用例目录
    case_dir = case_dir
    # 添加测试用例到测试容器中
    discover = unittest.defaultTestLoader.discover(
        case_dir, pattern="*.py", top_level_dir=None)
    for test_suite in discover:
        for test_case in test_suite:
            utest.addTests(test_case)
    alltestcase = utest
    print(utest)
    # 添加带时间的测试报告
    now = time.strftime("%Y-%m-%d %H-%M-%S", time.localtime(time.time()))
    # 测试报告的目录
    report = report_dir + now +  report_name
    fp = open(report, "wb")
    runner = HTMLTestRunner.HTMLTestRunner(
        stream=fp, title=title_name, description=description_name)
    runner.run(alltestcase)
