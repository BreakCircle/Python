# -*-coding:utf8-*-
import time
import HTMLTestRunner
import unittest
import sys

sys.path.append("D:\\zs\\public")
import runcases,find_report,mail

#定义参数
case_dir = "D:\\zs\\testcase"
report_dir = "D:\\zs\\report\\"
report_name = "discover.html"
title_name=u"Guest测试报告"
description_name = u"登录、多线程、检查元素"

#执行测试用例
runcases.runcases(case_dir,report_dir,report_name, title_name, description_name)

#找到最新的测试报告
file_new=find_report.find_newest_report(report_dir)
print (u"最新的测试报告为:%s" %file_new)

#发送最新的测试报告
mail.sendmail(file_new)